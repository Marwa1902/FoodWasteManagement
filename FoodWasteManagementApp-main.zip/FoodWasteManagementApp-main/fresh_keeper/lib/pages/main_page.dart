
import 'package:flutter/material.dart';
//import 'package:supabase_flutter/supabase_flutter.dart';
//import 'login_page.dart';

class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
